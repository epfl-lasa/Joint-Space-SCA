#include "IK.h"
using namespace std;
using namespace Eigen;

#ifdef __cplusplus
	extern "C" {
	#include "IKCG_solver.h"
	}
#endif

IKCG_Vars IKCG_vars;
IKCG_Params IKCG_params;
IKCG_Workspace IKCG_work;
IKCG_Settings IKCG_settings;

void get_info(Contact_Manager &points, VectorXd q0, MatrixXd &J, VectorXd &X0, VectorXd &Xr, VectorXd &slack)
{
	VectorXd dq0 = VectorXd::Zero(AIR_N_U);
	points.model.set_state(q0, dq0);
	int beg_index = 0;

	for(int index=0; index<points.size(); index++)
	{
		int body = points.EE[index].body;
		Vector3d offset = points.EE[index].offset;
		MatrixXd JJ = points.model.get_jacob(body, offset, CT_FULL);

		if(points.EE[index].contact_type==CT_FULL || points.EE[index].contact_type==CT_TRANSLATION)
		{
			X0.segment(beg_index,3)			= points.model.get_pos(body, offset);
			Xr.segment(beg_index,3)			= points.EE[index].ref_p.pos;
			slack.segment(beg_index,3)		= points.EE[index].T.slack_cost;
			J.block(beg_index,0,3,AIR_N_U) 	= JJ.block(0,0,3,AIR_N_U);
			if(index==0 && points.ifCoM)
			{
				X0.segment(beg_index,3)		= points.model.get_cm();
				J.block(beg_index,0,3,AIR_N_U) = points.model.get_cm_J();
			}
			beg_index += 3;
		}
		if(points.EE[index].contact_type==CT_FULL || points.EE[index].contact_type==CT_ROTATION)
		{
			VectorXd qact 					= quat_sub(points.model.get_orient_quat(body), points.EE[index].ref_o.pos);
			VectorXd qref 					= ang2quat(Vector3d(0,0,0));
			X0.segment(beg_index,3)			= qact.segment(0,3);
			Xr.segment(beg_index,3)			= qref.segment(0,3);
			slack.segment(beg_index,3)		= points.EE[index].R.slack_cost;
			J.block(beg_index,0,3,AIR_N_U) 	= JJ.block(3,0,3,AIR_N_U);
			beg_index += 3;
		}
	}
}

VectorXd solve_flex(MatrixXd &J, VectorXd dX, VectorXd &slack, VectorXd &damping, VectorXd &qref, VectorXd &qlow, VectorXd &qup)
{
	IKCG_set_defaults();
	IKCG_setup_indexing();

	for(int i=0;i<AIR_N_U;i++)
		memcpy(IKCG_params.J[i+1], &J(0,i),     sizeof(double)*(N_TASK));
	memcpy(IKCG_params.qlow,       &qlow[0],    sizeof(double)*(AIR_N_U-6));
	memcpy(IKCG_params.qup,        &qup[0],     sizeof(double)*(AIR_N_U-6));
	memcpy(IKCG_params.dx,         &dX[0],      sizeof(double)*(N_TASK));
	memcpy(IKCG_params.damping,    &damping[0], sizeof(double)*(AIR_N_U));
	memcpy(IKCG_params.qref,       &qref[0],    sizeof(double)*(AIR_N_U));
	memcpy(IKCG_params.slack,      &slack[0],   sizeof(double)*(N_TASK));

	VectorXd hard = slack;
	for(int i=0; i<hard.size(); i++)
		hard[i] = hard[i]==-1 ? 1 : 0;
	memcpy(IKCG_params.hard, &hard[0], sizeof(double)*(N_TASK));

	IKCG_settings.verbose = false;
	int iter = IKCG_solve();
	VectorXd dq = VectorXd::Zero(AIR_N_U);
	memcpy(&dq[0], IKCG_vars.dq, sizeof(double)*(AIR_N_U));
	return dq;
}

double return_error(Contact_Manager &points, VectorXd& ref_pos)
{
	// call exactly after solving IK
	VectorXd Xr = VectorXd::Zero(N_TASK);
	VectorXd X0 = VectorXd::Zero(N_TASK);
	VectorXd slack = VectorXd::Zero(N_TASK);
	MatrixXd J = MatrixXd::Zero(N_TASK, AIR_N_U);
	get_info(points, ref_pos, J, X0, Xr, slack);
	return vectorbig((Xr-X0).segment(18,3), (Xr-X0).segment(24,3)).norm();
}

double IK(Contact_Manager &points, IKPARAM &param, VectorXd& ref_pos, VectorXd freeze)
{
	timeval start, end;
	gettimeofday(&start, NULL);

	// initialize variables
	VectorXd Xr = VectorXd::Zero(N_TASK);
	VectorXd X0 = VectorXd::Zero(N_TASK);
	VectorXd slack = VectorXd::Zero(N_TASK);
	MatrixXd J = MatrixXd::Zero(N_TASK, AIR_N_U);
	VectorXd damping = param.damping * VectorXd::Ones(AIR_N_U);

	for(int j=0;j<param.num_iter;j++)
	{
		// recalculate gradients
		get_info(points, ref_pos, J, X0, Xr, slack);

		for(int i=0;i<AIR_N_U;i++)
			if(freeze[i]==1)
				J.block(0,i,N_TASK,1) *= 0;

		VectorXd qlow = points.model.qmin/180.0*M_PI - ref_pos.segment(6,AIR_N_U-6);
		VectorXd qup  = points.model.qmax/180.0*M_PI - ref_pos.segment(6,AIR_N_U-6);
		VectorXd dX   = Xr-X0;

		VectorXd qref = VectorXd::Zero(AIR_N_U);
		qref.segment(6,AIR_N_U-6) = - (qup+qlow) * 0.5 * 0;
		qref = qref.cwiseProduct(VectorXd::Ones(AIR_N_U)-freeze);

		// solve linearized CVXGEN problem
		VectorXd dq = solve_flex(J, dX, slack, damping, qref, qlow, qup);
		dq = dq.cwiseProduct(VectorXd::Ones(AIR_N_U)-freeze);

		// apply dq
		VectorXd q0 = getQ(ref_pos);
		ref_pos.segment(0,AIR_N_U) += dq;
		Vector4d w(0,0,0,0);
		w.segment(0,3) = quat2dc(q0) * dq.segment(3,3);
		VectorXd rotBase = quat_mul(quat_exp(0.5 * w), q0);
		ref_pos = setQ(ref_pos,rotBase);
	}


	gettimeofday(&end, NULL);
	return (end.tv_sec-start.tv_sec) + (end.tv_usec-start.tv_usec)/1e6;
}



