#include "Contacts.h"
using namespace std;

char names[5][6+1] = {"pelvis", "l_foot", "r_foot", "l_hand", "r_hand"};

void Geom_Point_print(Geom_Point in, __const char *str)
{
    VectorXd all(9);
    all[0] = in.pos[0];
    all[1] = in.pos[1];
    all[2] = in.pos[2];
    all[3] = in.vel[0];
    all[4] = in.vel[1];
    all[5] = in.vel[2];
    all[6] = in.acc[0];
    all[7] = in.acc[1];
    all[8] = in.acc[2];
    cout << str << all << endl;
}

void print_comparitive(__const char *str, Geom_Point ref, Geom_Point actual)
{
    printf("compare %s :\n",str);
    for(int i=0;i<3;i++)
        printf("| %3.2f <- %3.2f  \t| %3.2f <- %3.2f  \t| %3.2f <- %3.2f \n",
               ref.pos[i], actual.pos[i], ref.vel[i], actual.vel[i], ref.acc[i], actual.acc[i]);
}

////////////////// trajectory generation /////////////////////////

void apply_exp(double A, double t, double tau, double * pos, double * vel, double * acc)
{
    double e = exp(-(t/tau)*(t/tau));
    *pos += A * (1.0 - e);
    *vel += -A * (-2.0*t/tau/tau*e);
    *acc += -A * (-2.0/tau/tau*e + 4.0*t*t/tau/tau/tau/tau*e);
}

void apply_exp(double A, double t, double tau, VectorXd& pos, VectorXd& vel, VectorXd& acc, int index)
{
    apply_exp(A, t, tau, &pos[index], &vel[index], &acc[index]);
}

void apply_exp(double A, double t, double tau, Geom_Point &in, Dir_Axis index)
{
    apply_exp(A, t, tau, &in.pos[index], &in.vel[index], &in.acc[index]);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void apply_sin(double A, double t, double w, double phi, double * pos, double * vel, double * acc)
{
    *pos += A * sin(w*t+phi);
    *vel += A * w * cos(w*t+phi);
    *acc += -A * w * w * sin(w*t+phi);
}

void apply_sin(double A, double t, double w, double phi, VectorXd& pos, VectorXd& vel, VectorXd& acc, int index)
{
    apply_sin(A, t, w, phi, &pos[index], &vel[index], &acc[index]);
}

void apply_sin(double A, double t, double w, double phi, Geom_Point &in, Dir_Axis index)
{
    apply_sin(A, t, w, phi, &in.pos[index], &in.vel[index], &in.acc[index]);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void apply_sin2(double A, double t, double w, double * pos, double * vel, double * acc)
{
    *pos += A * pow(sin(w*t),2.0);
    *vel += A * w * sin(2.0*w*t);
    *acc += 2.0* A * w * w * cos(2.0*w*t);
}

void apply_sin2(double A, double t, double w, Geom_Point &in, Dir_Axis index)
{
    apply_sin2(A, t, w, &in.pos[index], &in.vel[index], &in.acc[index]);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void apply_sin3(double A, double t, double w, double * pos, double * vel, double * acc)
{
    A = 1.0/(1.0/4.0 + 1.0/12.0)/2.0*A;
    *pos += A * (sin(w*t)/2.0 - sin(3.0*w*t)/2.0/3.0);
    *vel += A * ((w*cos(t*w))/2.0 - (w*cos(3.0*t*w))/2.0);
    *acc += A * ((3.0*w*w*sin(3.0*t*w))/2.0 - (w*w*sin(t*w))/2.0);
}

void apply_sin3(double A, double t, double w, Geom_Point &in, Dir_Axis index)
{
    apply_sin3(A, t, w, &in.pos[index], &in.vel[index], &in.acc[index]);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void apply_expsin(double t, double A, double tau, double w, double phi, double* pos, double* vel, double* acc)
{
    double p=0, v=0, a=0;
    double p1=0, v1=0, a1=0;
    apply_exp(A, t, tau, &p, &v, &a);
    apply_sin(1.0, t, w, phi, &p1, &v1, &a1);
    *pos += p * p1;
    *vel += p * v1 + v * p1;
    *acc += p * a1 + 2.0 * v * v1 + a * p1;
}

void apply_expsin(double t, double A, double tau, double w, double phi, Geom_Point &in, Dir_Axis index)
{
    apply_expsin(t, A, tau, w, phi, &in.pos[index], &in.vel[index], &in.acc[index]);
}

void apply_expsin(double t, double A, double tau, double w, double phi, Vector3d& pos, Vector3d& vel, Vector3d& acc, int index)
{
    apply_expsin(t, A, tau, w, phi, &pos[index], &vel[index], &acc[index]);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void apply_fexp(double t, double A, double tau, double f, double df, double ddf, VectorXd& pos, VectorXd& vel, VectorXd& acc, int index)
{
    double p=0, v=0, a=0;
    apply_exp(A, t, tau, &p, &v, &a);
    pos[index] += p * f;
    vel[index] += p * df + v * f;
    acc[index] += p * ddf + 2.0 * v * df + a * f;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void exp_transition(double t, double tau,
                    double p, double v, double a,
                    double p_des, double v_des, double a_des,
                    double &p_out, double &v_out, double &a_out)
{
    double e = exp(-t*t/tau/tau);
    double de = (-2.0*t/tau/tau) * e;
    double dde = (-2.0/tau/tau) * e + (-2.0*t/tau/tau) * de;
    p_out = (p-p_des) * e + p_des;
    v_out = (v-v_des) * e + (p-p_des) * de + v_des;
    a_out = (a-a_des) * e + (v-v_des) * de * 2.0 + (p-p_des) * dde + a_des;
}

void exp_transition(double t, double tau,
                    Vector3d p, Vector3d v, Vector3d a,
                    Vector3d p_des, Vector3d v_des, Vector3d a_des,
                    Vector3d &p_out, Vector3d &v_out, Vector3d &a_out)
{
    for(int i=0;i<3;i++)
        exp_transition( t, tau,
                        p[i], v[i], a[i],
                        p_des[i], v_des[i], a_des[i],
                        p_out[i], v_out[i], a_out[i]);
}

void exp_transition(double t, double tau, Geom_Point & init, Geom_Point & end, Geom_Point & out)
{
    exp_transition(t, tau,
                   init.pos, init.vel, init.acc,
                    end.pos, end.vel, end.acc,
                    out.pos, out.vel, out.acc);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////

void slerp(double t, double T, double tau, Geom_Point & init, Geom_Point & end, Geom_Point & out)
{
    for(int i=0;i<3;i++)
        slerp(t, T, tau, init, end, out, (Dir_Axis)i);
}

void slerp(double t, double T, double tau, Geom_Point & init, Geom_Point & end, Geom_Point & out, Dir_Axis index)
{
    t -= T/2.0;
    double e = exp(-t/tau);
    double de = (-1.0/tau) * e;
    double dde = (-1.0/tau) * de;
    double s = pow(1.0+e,-1);
    double ds = -de*pow(1.0+e,-2);
    double dds = -dde*pow(1.0+e,-2) + 2.0*pow(de,2)*pow(1.0+e,-3);
    out.pos[index] = init.pos[index] + (end.pos[index] - init.pos[index]) * s;
    out.vel[index] = init.vel[index] + (end.vel[index] - init.vel[index]) * s + (end.pos[index] - init.pos[index]) * ds;
    out.acc[index] = init.acc[index] + (end.acc[index] - init.acc[index]) * s +
                    (end.vel[index] - init.vel[index]) * ds * 2.0 +
                    (end.pos[index] - init.pos[index]) * dds;
}

void slerp_sin(double t, double T, Geom_Point & init, Geom_Point & end, Geom_Point & out)
{
    for(int i=0;i<3;i++)
        slerp_sin(t, T, init, end, out, (Dir_Axis)i);
}

void slerp_sin(double t, double T, Geom_Point & init, Geom_Point & end, Geom_Point & out, Dir_Axis index)
{
    double theta = M_PI/T;
    double s = 2.0*t-1.0/theta*sin(2.0*theta*t);
    double ds = 2.0 - 2.0*cos(2.0*theta*t);
    double dds = 4.0 * theta * sin(2.0*theta*t);
    out.pos[index] = init.pos[index] + (end.pos[index] - init.pos[index]) * s;
    out.vel[index] = init.vel[index] + (end.vel[index] - init.vel[index]) * s + (end.pos[index] - init.pos[index]) * ds;
    out.acc[index] = init.acc[index] + (end.acc[index] - init.acc[index]) * s +
                    (end.vel[index] - init.vel[index]) * ds * 2.0 +
                    (end.pos[index] - init.pos[index]) * dds;
}

void slerp_poly(double t, double T, Geom_Point & init, Geom_Point & end, Geom_Point & out)
{
    for(int i=0;i<3;i++)
        slerp_poly(t, T, init, end, out, (Dir_Axis)i);
}

void slerp_poly(double t, double T, Geom_Point & init, Geom_Point & end, Geom_Point & out, Dir_Axis index)
{
    double p = t/T;
    double a = 6, b = -15, c = 10;
    double s = p*p*p*(a*p*p + b*p + c);
    double ds = p*p*(5*a*p*p + 4*b*p + 3*c)/T;
    double dds = p*(20*a*p*p + 12*b*p + 6*c)/T/T;
    out.pos[index] = init.pos[index] + (end.pos[index] - init.pos[index]) * s;
    out.vel[index] = init.vel[index] + (end.vel[index] - init.vel[index]) * s + (end.pos[index] - init.pos[index]) * ds;
    out.acc[index] = init.acc[index] + (end.acc[index] - init.acc[index]) * s +
                    (end.vel[index] - init.vel[index]) * ds * 2.0 +
                    (end.pos[index] - init.pos[index]) * dds;
}

void exp_transition_quat(double t, double T, double tau, Geom_Rot & init, Geom_Rot & end, Geom_Rot & out)
{
    t -= T/2.0;
    double e = exp(-t/tau);
    double de = (-1.0/tau) * e;
    double dde = (-1.0/tau) * de;

    // sigmoid
    double s = pow(1.0+e,-1);
    double ds = -de*pow(1.0+e,-2);
    double dds = -dde*pow(1.0+e,-2) + 2.0*pow(de,2)*pow(1.0+e,-3);

    //between 0 and 1
    e = s;
    de = ds;
    dde = dds;

    t += T/2.0;

    VectorXd o0t = 0.5*(0.5 * pow(t-0.0,2) * quat_deriv(init.acc) + (t-0.0) * quat_deriv(init.vel)) + quat_log(init.pos);
    VectorXd w0t = (t-0.0) * quat_deriv(init.acc) + quat_deriv(init.vel);
    VectorXd al0t = quat_deriv(init.acc);
    VectorXd q0 = quat_exp(o0t);
    VectorXd dq0 = 0.5 * quat_cross(q0, w0t);
    VectorXd ddq0 = 0.5 * quat_cross(q0,al0t) + 0.5 * quat_cross(dq0,w0t);

    VectorXd o1t = 0.5*(0.5 * pow(t-T,2) * quat_deriv(end.acc) + (t-T) * quat_deriv(end.vel)) + quat_log(end.pos);
    VectorXd w1t = (t-T) * quat_deriv(end.acc) + quat_deriv(end.vel);
    VectorXd al1t = quat_deriv(end.acc);
    VectorXd q1 = quat_exp(o1t);
    VectorXd dq1 = 0.5 * quat_cross(q1, w1t);
    VectorXd ddq1 = 0.5 * quat_cross(q1,al1t) + 0.5 * quat_cross(dq1,w1t);

    VectorXd q0i = quat_inverse(q0);
    VectorXd dq0i = -quat_cross(q0i, dq0, q0i);
    VectorXd ddq0i = -quat_cross(q0i, quat_cross(ddq0,q0i) + 2.0*quat_cross(dq0,dq0i));

    VectorXd A = quat_cross(q1, q0i);
    VectorXd dA = quat_cross(dq1, q0i) + quat_cross(q1, dq0i);
    VectorXd ddA =   quat_cross(ddq1, q0i) + 2 * quat_cross(dq1, dq0i) + quat_cross(q1, ddq0i);

    if(A[3]<0)
    {
        A *= -1;
        dA *= -1;
        ddA *= -1;
    }

    VectorXd At = quat_pow(A,e);
    VectorXd dAt = e * quat_cross(dA, quat_pow(A,e-1));
    VectorXd ddAt = e * quat_cross(ddA, quat_pow(A,e-1)) +
                    e * (e-1) * quat_cross(dA, dA, quat_pow(A,e-2));

    VectorXd pm = quat_cross(At,q0);
    VectorXd vm = quat_cross(dAt,q0) + quat_cross(At,dq0);
    VectorXd am = quat_cross(ddAt,q0) + 2.0 * quat_cross(dAt,dq0) + quat_cross(At,ddq0);

    vm = vm + de * quat_cross(quat_log(A) , pm);
    am = am + dde * quat_cross(quat_log(A) , pm) +
              de * de * quat_cross(quat_log(A) , quat_log(A) , pm);

    VectorXd wm = 2.0 * quat_cross(quat_inverse(pm) , vm);
    VectorXd alm = 2.0 * quat_cross(quat_inverse(pm) , am - 0.5 * quat_cross(vm,wm));

    out.pos = pm;
    out.vel = Vector3d(wm[0], wm[1], wm[2]);
    out.acc = Vector3d(alm[0], alm[1], alm[2]);
}

Contact::Contact()
{
    initialize_contact();
}

Contact::~Contact()
{
    body = 0;
}

void Contact::init(Contact_Name Name,
            int Body,
            Vector3d Offset,
            constraint_type Contact_type,
            Point_Status Status,
			double length,
			double width)
{
    initialize_contact();
    name = Name;
    body = Body;
    offset = Offset;
    contact_type = Contact_type;
    status = Status;
	w_x = Vector3d(-1,1,0) * length / 2.0;
	w_y = Vector3d(-1,1,0) * width / 2.0;
}

void Contact::initialize_contact()
{
    name = (Contact_Name)-1;
    body = 0;
    offset = zero_v3;
    contact_type = CT_FULL;
    status = PS_NO_CONTROL;
    used_for_odometry = false;

    Geom_Point * gp[3] = {&p, &init_p, &ref_p};
    for(int i=0;i<3;i++)
    {
        gp[i]->pos = zero_v3;
        gp[i]->vel = zero_v3;
        gp[i]->acc = zero_v3;
    }

	Geom_Rot * go[3] = {&o, &init_o, &ref_o};
    for(int i=0;i<3;i++)
    {
        go[i]->pos = zero_quat;
        go[i]->vel = zero_v3;
        go[i]->acc = zero_v3;
    }

    Dyn_Point * dp[2] = {&T, &R};
    for(int i=0;i<2;i++)
    {
        dp[i]->acc_ref = zero_v3;
        dp[i]->J = MatrixXd(1,1).setZero();
        dp[i]->dJdq = zero_v3;
        dp[i]->F_est = zero_v3;
        dp[i]->F_ref = zero_v3;
        dp[i]->F_sens = zero_v3;

        dp[i]->F_cost = zero_v3;
        dp[i]->K = Vector3d(20, 3, 1);
        dp[i]->slack_cost = zero_v3;
    }

    cop = zero_v3;
    n1 = Vector3d(1,0,0);
    n2 = Vector3d(0,1,0);
    n3 = Vector3d(0,0,1);
    w_x = Vector3d(-100,100,0);
    w_y = Vector3d(-100,100,0);
    mu = 1;
    muR = 1;
}

Contact_Manager::Contact_Manager()
{
	ifCoM = true;
	base = zero_v3;
	dbase = zero_v3;
	heading = 0;

    model.init();
    EE.resize(NUM_Contact);

	// this combination of contact points is fixed since the jacobian in the IK solver has hard-coded sparsity pattern
	EE[CN_CM].init(CN_CM, body_base,   offset_base,   CT_FULL, 		PS_FLOATING,  0              , 0             );
	EE[CN_LF].init(CN_LF, body_l_foot, offset_l_foot, CT_FULL, 		PS_CONTACTED, foot_length*0.8, foot_width*0.8);
	EE[CN_RF].init(CN_RF, body_r_foot, offset_r_foot, CT_FULL, 		PS_CONTACTED, foot_length*0.8, foot_width*0.8);
	EE[CN_LH].init(CN_LH, body_l_hand, offset_l_hand, CT_FULL, 		PS_FLOATING,  hand_length*0.8, hand_width*0.8);
	EE[CN_RH].init(CN_RH, body_r_hand, offset_r_hand, CT_FULL, 		PS_FLOATING,  hand_length*0.8, hand_width*0.8);
	EE[CN_TO].init(CN_TO, body_torso , offset_torso , CT_ROTATION, 	PS_FLOATING,  0              , 0             );
	EE[CN_HD].init(CN_HD, body_head  , offset_head  , CT_ROTATION, 	PS_FLOATING,  0              , 0             );
}

Contact_Manager::~Contact_Manager()
{
    EE.clear();
}

void Contact_Manager::update_kinematics()
{
	// assumes model.set_state is called before
    for(unsigned int i=0;i<EE.size();i++)
    {
        EE[i].p.pos  = model.get_pos(EE[i].body,EE[i].offset);
        EE[i].p.vel  = model.get_vel(EE[i].body,EE[i].offset);
        EE[i].T.J    = model.get_jacob(EE[i].body, EE[i].offset, CT_TRANSLATION);
        EE[i].o.pos  = model.get_orient_quat(EE[i].body);
        EE[i].o.vel  = model.get_angvel(EE[i].body);
        EE[i].R.J    = model.get_jacob(EE[i].body, EE[i].offset, CT_ROTATION);
        if(i == 0 && ifCoM)
        {
            EE[i].p.pos  = model.get_cm();
            EE[i].p.vel  = model.get_cm_v();
            EE[i].T.J    = model.get_cm_J();
        }
        // a rough estimation of the contact normal.
        EE[i].n1 = model.get_pos(EE[i].body,Vector3d(1,0,0)) - model.get_pos(EE[i].body,zero_v3);
        EE[i].n2 = model.get_pos(EE[i].body,Vector3d(0,1,0)) - model.get_pos(EE[i].body,zero_v3);
        EE[i].n3 = model.get_pos(EE[i].body,Vector3d(0,0,1)) - model.get_pos(EE[i].body,zero_v3);
    }
	VectorXd zero_acc = VectorXd::Zero(AIR_N_U);
    model.set_acc(zero_acc);
    for(unsigned int i=0;i<EE.size();i++)
    {
        EE[i].T.dJdq = model.get_acc(EE[i].body,EE[i].offset);
        EE[i].R.dJdq = model.get_angacc(EE[i].body);
        if(i==0 && ifCoM)
            EE[i].T.dJdq = model.get_cm_a();
    }
}

void Contact_Manager::update_dynamics()
{
	// assumes model.set_state and model.set_acc are called before
    for(unsigned int i=0;i<EE.size();i++)
    {
        EE[i].p.acc  = model.get_acc(EE[i].body,EE[i].offset);
        EE[i].o.acc  = model.get_angacc(EE[i].body);
        if(i == 0 && ifCoM)
            EE[i].p.acc  = model.get_cm_a();
    }
}

void Contact_Manager::save_initial_contacts()
{
    for(unsigned int i=0;i<EE.size();i++)
    {
        EE[i].init_p.pos = model.get_pos(EE[i].body,EE[i].offset);
        EE[i].init_o.pos = model.get_orient_quat(EE[i].body);
        EE[i].init_p.vel = zero_v3;
        EE[i].init_p.acc = zero_v3;
        EE[i].init_o.vel = zero_v3;
        EE[i].init_o.acc = zero_v3;
        if(i == 0 && ifCoM)
            EE[i].init_p.pos = model.get_cm();
    }
}

unsigned int Contact_Manager::size()
{
    return EE.size();
}

void Contact_Manager::tasks(MatrixXd &J, VectorXd &dJdq, VectorXd &acc, VectorXd &slack)
{
    J = MatrixXd::Zero(N_TASK,AIR_N_U);
    dJdq = VectorXd::Zero(N_TASK);
    acc = VectorXd::Zero(N_TASK);
    slack = VectorXd::Zero(N_TASK);
    int beg_index = 0;
    for(unsigned int i=0;i<EE.size();i++)
    {
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_TRANSLATION)
		{
		    J.block(beg_index,0,3,AIR_N_U) 	= EE[i].T.J;
		    dJdq.segment(beg_index,3) 		= EE[i].T.dJdq;
		    acc.segment(beg_index,3) 		= EE[i].T.acc_ref;
		    slack.segment(beg_index,3) 		= EE[i].T.slack_cost;
		    beg_index += 3;
		}

		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_ROTATION)
		{
		    J.block(beg_index,0,3,AIR_N_U) 	= EE[i].R.J;
		    dJdq.segment(beg_index,3) 		= EE[i].R.dJdq;
		    acc.segment(beg_index,3) 		= EE[i].R.acc_ref;
		    slack.segment(beg_index,3) 		= EE[i].R.slack_cost;
		    beg_index += 3;
		}
    }
}

VectorXd Contact_Manager::get_mult()
{
    VectorXd mult = VectorXd::Zero(AIR_N_U);
    for(unsigned int i=1;i<EE.size();i++)
    {
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_TRANSLATION)
        	mult += EE[i].T.J.transpose() * EE[i].T.F_est;
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_ROTATION)
        	mult += EE[i].R.J.transpose() * EE[i].R.F_est;
    }
    return mult;
}

VectorXd Contact_Manager::get_virtual_mult()
{
    VectorXd mult = VectorXd::Zero(AIR_N_U);
    for(unsigned int i=0;i<EE.size();i++)
    {
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_TRANSLATION)
	        mult += EE[i].T.J.transpose() * EE[i].T.F_ref;
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_ROTATION)
	        mult += EE[i].R.J.transpose() * EE[i].R.F_ref;
    }
    return mult;
}

void Contact_Manager::control_position(Contact_Name i, Geom_Point ref)
{
    EE[i].T.acc_ref =  (ref.pos - EE[i].p.pos) * EE[i].T.K[0] +
                          (ref.vel - EE[i].p.vel) * EE[i].T.K[1] +
                           ref.acc * EE[i].T.K[2];
}

void Contact_Manager::control_orientation(Contact_Name i, Geom_Rot ref)
{
    // r : ref frame
    // e : end effector frame
    // i : inertial frame
    // t : theta, rotation matrix
    // w : omega, angular velocity
    // a : angular velocity

    Geom_Rot act = EE[i].o;

    MatrixXd  itr = quat2dc(ref.pos);
    Vector3d iwr = ref.vel;
    Vector3d iar = ref.acc;

    MatrixXd  ite = quat2dc(act.pos);
    Vector3d iwe = act.vel;

    MatrixXd rte = itr.inverse() * ite;
    Vector3d rwe = itr.inverse() * (iwe - iwr);
    Vector3d rae = dc2ang(rte) * (-EE[i].R.K[0]) + rwe * (-EE[i].R.K[1]);
    Vector3d rw = itr.inverse() * iwr;

    Vector3d iae =  itr * skew_symmetric(rw) * rwe +
                    itr * rae +
                    iar;

    EE[i].R.acc_ref = iae;
}

void Contact_Manager::control(Contact_Name i, Geom_Point ref_pos, Geom_Rot ref_ori, bool if_force)
{
	if(if_force)
	{
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_TRANSLATION)
			EE[i].T.F_ref    = EE[i].T.K[0] * (EE[i].ref_p.pos - EE[i].p.pos)
						    + EE[i].T.K[1] * (EE[i].ref_p.vel - EE[i].p.vel);
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_ROTATION)
			EE[i].R.F_ref    = EE[i].R.K[0] * quat_log(quat_sub(EE[i].ref_o.pos, EE[i].o.pos)).segment(0,3)
							+ EE[i].R.K[1] * (EE[i].ref_o.vel - EE[i].o.vel);
	}
	else
	{
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_TRANSLATION)
		    control_position(i, ref_pos);
		if(EE[i].contact_type==CT_FULL || EE[i].contact_type==CT_ROTATION)
    		control_orientation(i, ref_ori);
	}
}

void Contact_Manager::load_tasks(VectorXd com, VectorXd lf, VectorXd rf, VectorXd lh, VectorXd rh)
{
	EE[CN_CM].ref_p.pos = com.segment(0,3);
	EE[CN_CM].ref_o.pos = com.segment(3,4);
	EE[CN_TO].ref_o.pos = com.segment(3,4);
	EE[CN_HD].ref_o.pos = com.segment(3,4);

	EE[CN_LF].ref_p.pos = lf.segment(0,3);
	EE[CN_RF].ref_p.pos = rf.segment(0,3);
	EE[CN_LF].ref_o.pos = lf.segment(3,4);
	EE[CN_RF].ref_o.pos = rf.segment(3,4);

	EE[CN_LH].ref_p.pos = lh.segment(0,3);
	EE[CN_RH].ref_p.pos = rh.segment(0,3);
	EE[CN_LH].ref_o.pos = lh.segment(3,4);
	EE[CN_RH].ref_o.pos = rh.segment(3,4);
}

void print_VectorXd(VectorXd x, double precision)
{
	for(int i=0; i<x.size();i++)
		cout << fixed << setprecision( precision ) << std::setw( 11 ) << x[i];
	cout << endl;
}

void Contact_Manager::print_acc_ref()
{
    printf("----- Contact Ref. Accelerations-------------------------- \n");
    for(unsigned int i=0;i<EE.size();i++)
	{
		cout << names[i];
		print_VectorXd(vectorbig(EE[i].T.acc_ref, EE[i].R.acc_ref), 2);
	}
}

void Contact_Manager::print_forces()
{
    printf("----- Contact forces -------------------------------------- \n");
    for(unsigned int i=0;i<EE.size();i++)
	{
		cout << names[i];
		print_VectorXd(vectorbig(EE[i].T.F_sens, EE[i].R.F_sens), 2);
	}
}

void Contact_Manager::print_IK_errors()
{
    printf("----- Contact IK position errors -------------------------- \n");
    for(unsigned int i=0;i<EE.size();i++)
	{
		cout << names[i];
		print_VectorXd(vectorbig(EE[i].ref_p.pos- EE[i].p.pos, quat_sub(EE[i].ref_o.pos, EE[i].o.pos).segment(0,3)), 3);
	}
}

void Contact_Manager::print_ID_errors()
{
    printf("----- Contact ID acceleration errors ---------------------- \n");
    for(unsigned int i=0;i<EE.size();i++)
	{
		cout << names[i];
		print_VectorXd(vectorbig(EE[i].T.acc_ref-EE[i].p.acc, EE[i].R.acc_ref-EE[i].o.acc),2);
	}
}