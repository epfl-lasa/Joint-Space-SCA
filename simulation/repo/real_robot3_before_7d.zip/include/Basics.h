/*!
 * \file Basics.hpp
 *
 * \author Salman Faraji
 * \date 10.2.2015
 *
 * The basic definitions, file inclusions and math functions
 */

#pragma once

// C++ standard headers
#include <cmath>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <fstream>
#include <vector>
#include "vector"
#include <unistd.h>
#include <string>
#include <time.h>
#include <iostream>
#include <iomanip>
#include <termios.h>
#include <sys/time.h>
#include <Eigen/Dense>
#include <quaternions.h>
#include "utils.h"

#define inf 1e20

// Eigen redefinition ///////////////////////////////////////////////////////////////////////////
#define zero_v3 Vector3d(0.0,0.0,0.0)
#define zero_quat Vector4d(0.0,0.0,0.0,1.0)

// Eigen redefinition ///////////////////////////////////////////////////////////////////////////

/*!
 * \class Exception
 *
 * \brief In case of run-time error, this functrion could be called.
 *
 * It has the possibility to show an error message
 *
 * \author Salman Faraji
 * \date 10.2.2015
 */
class Exception
{
public:
    const char* msg;
    Exception(const char* arg)
    : msg(arg)
    {printf("Error: %s \n", arg);}
};

//! Cartesian space directions, used to access vectors
enum Dir_Axis {X_DIR=0, Y_DIR, Z_DIR};

//! Thresholding a value to certain bounds
/*!
 * \param[in] in the input value
 * \param[in] up the upper bound
 * \param[in] down the lower bound
 * \param[out] double truncated
 */
double truncate_command(double in, double up, double down);
VectorXd truncate_command(VectorXd in, double up, double down);

//! reading keyboard functions
int khbit();
void nonblock(int state);
bool keyState(char key);


