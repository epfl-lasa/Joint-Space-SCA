#pragma once

#include "Contacts.h"

class Box
{
public:

	VectorXd sens_pos;
	VectorXd sens_vel;
	VectorXd ref_pos;
	Vector3d dim;
	double expansion;
	int grasp_axis;

	Box();
	~Box() {};
	void set_pos_from_top_marker(VectorXd pos);
	void set_pos_from_center_marker(VectorXd pos);
	VectorXd get_hand(bool left);
};

class Manipulation
{
public:

	VectorXd bias_lh, bias_rh;
	VectorXd avg_lh, avg_rh;
	VectorXd force_lh, force_rh;
	VectorXd reading_lh, reading_rh;

	double gamma;
	double dgamma;
	double tau;
	double dtau;
	double orientation_factor;
	MatrixXd A_V;
	MatrixXd A;
	VectorXd xR;
	VectorXd xV;
	VectorXd qR;
	VectorXd qV;
	double obj_width_dyn;
	double force_amp;

	Manipulation();
	~Manipulation() {};

	void set_start_point(Box &box);

	void read_forces(Contact_Manager &points);

	void initial_filtering(Contact_Manager &points, double dt);

	void secondary_filtering(Contact_Manager &points, double dt);

	void compliance_control(Contact_Manager &points, double force_amp);

	// Dynamical System functions

	void update(bool reachable, double dt, Box &box, bool grasp);

	bool grasped(double eps_obj);

	bool released(double eps_obj);

	VectorXd get_hand(Box &box, VectorXd center, double shrink, bool left);

	VectorXd get_hand(Box &box, bool left);
};

//! add two transformations together
VectorXd trans7_add(VectorXd a, VectorXd b);

//! invert a transformation
VectorXd trans7_invert(VectorXd a);

//! describe a transformation a in b
VectorXd trans7_sub(VectorXd a, VectorXd b);

//! scale a transformation
VectorXd trans7_scale(VectorXd a, double b);

//! threshold object position
void apply_mocap_thresholds(VectorXd &Object);
